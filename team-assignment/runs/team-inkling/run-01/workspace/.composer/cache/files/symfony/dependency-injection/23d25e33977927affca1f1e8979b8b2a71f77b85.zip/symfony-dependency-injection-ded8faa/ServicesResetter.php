<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Component\DependencyInjection;

use ProxyManager\Proxy\LazyLoadingInterface;
use Symfony\Component\VarExporter\LazyObjectInterface;

/**
 * Resets provided services.
 *
 * @author Alexander M. Turek <me@derrabus.de>
 * @author Nicolas Grekas <p@tchwork.com>
 */
class ServicesResetter implements ServicesResetterInterface
{
    /**
     * @param \Traversable<string, object>   $resettableServices
     * @param array<string, string|string[]> $resetMethods
     */
    public function __construct(
        private \Traversable $resettableServices,
        private array $resetMethods,
        private ?\WeakMap $resetMap = null,
    ) {
    }

    public function reset(): void
    {
        $throwable = null;

        foreach ($this->resettableServices as $id => $service) {
            $this->resetInstance($service, (array) $this->resetMethods[$id], $throwable);
        }

        if (null !== $this->resetMap) {
            foreach ($this->resetMap as $service => $methods) {
                $this->resetInstance($service, $methods, $throwable);
            }
        }

        if (null !== $throwable) {
            throw $throwable;
        }
    }

    private function resetInstance(object $service, array $methods, ?\Throwable &$throwable = null): void
    {
        if ($this->isUninitializedLazyObject($service)) {
            return;
        }

        foreach ($methods as $resetMethod) {
            if ('?' === $resetMethod[0] && !method_exists($service, $resetMethod = substr($resetMethod, 1))) {
                continue;
            }

            try {
                $service->$resetMethod();
            } catch (\Throwable $e) {
                // failing to reset one service should not prevent resetting the remaining ones
                $throwable ??= $e;
            }
        }
    }

    private function isUninitializedLazyObject(object $service): bool
    {
        if ($service instanceof LazyObjectInterface && !$service->isLazyObjectInitialized(true)) {
            return true;
        }

        /** @psalm-suppress UndefinedClass */
        if ($service instanceof LazyLoadingInterface && !$service->isProxyInitialized()) {
            return true;
        }

        return (new \ReflectionClass($service))->isUninitializedLazyObject($service);
    }
}

if (!class_exists('Symfony\Component\HttpKernel\DependencyInjection\ServicesResetter', false)) {
    class_alias(ServicesResetter::class, 'Symfony\Component\HttpKernel\DependencyInjection\ServicesResetter');
}
