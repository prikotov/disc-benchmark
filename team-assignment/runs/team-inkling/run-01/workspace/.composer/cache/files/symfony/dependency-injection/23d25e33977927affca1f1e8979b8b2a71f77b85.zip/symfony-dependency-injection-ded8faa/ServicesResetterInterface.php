<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Component\DependencyInjection;

use Symfony\Contracts\Service\ResetInterface;

/**
 * Resets provided services.
 */
interface ServicesResetterInterface extends ResetInterface
{
}

if (!interface_exists('Symfony\Component\HttpKernel\DependencyInjection\ServicesResetterInterface', false)) {
    class_alias(ServicesResetterInterface::class, 'Symfony\Component\HttpKernel\DependencyInjection\ServicesResetterInterface');
}
