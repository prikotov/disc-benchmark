<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Flex;

use Composer\IO\IOInterface;
use Composer\Package\AliasPackage;
use Composer\Package\PackageInterface;
use Composer\Package\RootPackageInterface;
use Composer\Semver\Constraint\Constraint;
use Composer\Semver\Intervals;
use Composer\Semver\VersionParser;

/**
 * @author Nicolas Grekas <p@tchwork.com>
 */
class PackageFilter
{
    private $versions;
    private $versionParser;
    private $symfonyRequire;
    private $symfonyConstraints;
    private $downloader;
    private $io;
    private $ignorePreleases;
    private $notifiedRestriction = false;
    private $warnedPackages = [];

    public function __construct(IOInterface $io, string $symfonyRequire, Downloader $downloader, bool $ignorePreleases = false)
    {
        $this->versionParser = new VersionParser();
        // "7.4" and "7.4.x" mean "7.4.*", while ">=7.4.x" needs "7.4.x-dev" to be parsed
        $this->symfonyRequire = preg_replace(['/^v?(\d++(?:\.\d++)?)\.x$/i', '/^v?(\d++\.\d++)$/', '/\.x$/'], ['$1.*', '$1.*', '.x-dev'], $symfonyRequire);
        $this->symfonyConstraints = '' !== $symfonyRequire ? $this->versionParser->parseConstraints($this->symfonyRequire) : null;

        if ($this->symfonyConstraints instanceof Constraint && '==' === $this->symfonyConstraints->getOperator() && preg_match('/^[=v\s]*+(\d++(?:\.\d++)?)/', $symfonyRequire, $m)) {
            $io->writeError(\sprintf('<warning>SYMFONY_REQUIRE="%s" is an exact version constraint. Did you mean "^%s"?</>', $symfonyRequire, $m[1]));
        }

        $this->downloader = $downloader;
        $this->io = $io;
        $this->ignorePreleases = $ignorePreleases;
    }

    /**
     * @param PackageInterface[] $data
     * @param PackageInterface[] $lockedPackages
     *
     * @return PackageInterface[]
     */
    public function removeLegacyPackages(array $data, RootPackageInterface $rootPackage, array $lockedPackages): array
    {
        if ($this->ignorePreleases) {
            $filteredPackages = [];
            foreach ($data as $package) {
                if (\in_array($package->getStability(), ['stable', 'dev'], true)) {
                    $filteredPackages[] = $package;
                }
            }
            $data = $filteredPackages;
        }

        if (!$this->symfonyConstraints || !$data) {
            return $data;
        }

        $lockedVersions = [];
        foreach ($lockedPackages as $package) {
            $lockedVersions[$package->getName()] = [$package->getVersion()];
            if ($package instanceof AliasPackage) {
                $lockedVersions[$package->getName()][] = $package->getAliasOf()->getVersion();
            }
        }

        $rootConstraints = [];
        foreach ($rootPackage->getRequires() + $rootPackage->getDevRequires() as $name => $link) {
            $rootConstraints[$name] = $link->getConstraint();
        }
        $stabilityFlags = $rootPackage->getStabilityFlags();

        $knownVersions = null;
        $filteredPackages = [];
        $symfonyPackages = [];
        $oneSymfony = false;
        foreach ($data as $package) {
            $name = $package->getName();
            $versions = [$package->getVersion()];
            if ($package instanceof AliasPackage) {
                $versions[] = $package->getAliasOf()->getVersion();
            }

            if ('symfony/symfony' !== $name && (
                array_intersect($versions, $lockedVersions[$name] ?? [])
                || (($knownVersions ??= $this->getVersions()) && !isset($knownVersions['splits'][$name]))
                || ('symfony/psr-http-message-bridge' === $name && 6.4 > $versions[0])
            )) {
                $filteredPackages[] = $package;
                continue;
            }

            if ('symfony/symfony' !== $name && isset($rootConstraints[$name]) && !Intervals::haveIntersections($this->symfonyConstraints, $rootConstraints[$name])) {
                // the root constraint wins, e.g. to allow requiring a dev version,
                // but one that doesn't ask for unstable versions is likely a mistake
                if (!isset($stabilityFlags[$name]) && !isset($this->warnedPackages[$name])) {
                    $this->warnedPackages[$name] = true;
                    $this->io->writeError(\sprintf('<warning>Version constraint "%s" for "%s" has no intersection with "%s", keeping the package unrestricted</>', $rootConstraints[$name]->getPrettyString(), $name, $this->symfonyRequire));
                }
                $filteredPackages[] = $package;
                continue;
            }

            if (null !== $alias = $package->getExtra()['branch-alias'][$package->getVersion()] ?? null) {
                $versions[] = $this->versionParser->normalize($alias);
            }

            foreach ($versions as $version) {
                if ($this->symfonyConstraints->matches(new Constraint('==', $version))) {
                    $filteredPackages[] = $package;
                    $oneSymfony = $oneSymfony || 'symfony/symfony' === $name;
                    continue 2;
                }
            }

            if ('symfony/symfony' === $name) {
                $symfonyPackages[] = $package;
            } elseif (!$this->notifiedRestriction) {
                $this->notifiedRestriction = true;
                $this->io->writeError(\sprintf('<info>Restricting packages listed in "symfony/symfony" to "%s"</>', $this->symfonyRequire));
            }
        }

        if ($symfonyPackages && !$oneSymfony) {
            $filteredPackages = array_merge($filteredPackages, $symfonyPackages);
        }

        return $filteredPackages;
    }

    private function getVersions(): array
    {
        if (null !== $this->versions) {
            return $this->versions;
        }

        $versions = $this->downloader->getVersions();
        $this->downloader = null;
        $okVersions = [];

        if (!isset($versions['splits'])) {
            throw new \LogicException('The Flex index is missing a "splits" entry. Did you forget to add "flex://defaults" in the "extra.symfony.endpoint" array of your composer.json?');
        }
        foreach ($versions['splits'] as $name => $vers) {
            foreach ($vers as $i => $v) {
                if (!isset($okVersions[$v])) {
                    $okVersions[$v] = false;
                    $w = '.x' === substr($v, -2) ? $versions['next'] : $v;

                    for ($j = 0; $j < 60; ++$j) {
                        if ($this->symfonyConstraints->matches(new Constraint('==', $w.'.'.$j.'.0'))) {
                            $okVersions[$v] = true;
                            break;
                        }
                    }
                }

                if (!$okVersions[$v]) {
                    unset($vers[$i]);
                }
            }

            if (!$vers || $vers === $versions['splits'][$name]) {
                unset($versions['splits'][$name]);
            }
        }

        return $this->versions = $versions;
    }
}
