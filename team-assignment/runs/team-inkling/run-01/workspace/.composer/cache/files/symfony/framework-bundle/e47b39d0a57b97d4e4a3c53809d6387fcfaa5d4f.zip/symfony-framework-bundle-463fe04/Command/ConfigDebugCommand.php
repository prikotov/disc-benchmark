<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Bundle\FrameworkBundle\Command;

use Psr\Container\ContainerInterface;
use Symfony\Component\Config\Definition\ConfigurationInterface;
use Symfony\Component\Config\Definition\Processor;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Completion\CompletionInput;
use Symfony\Component\Console\Completion\CompletionSuggestions;
use Symfony\Component\Console\Exception\InvalidArgumentException;
use Symfony\Component\Console\Exception\LogicException;
use Symfony\Component\Console\Formatter\OutputFormatter;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\DependencyInjection\Compiler\ValidateEnvPlaceholdersPass;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Extension\ConfigurationExtensionInterface;
use Symfony\Component\DependencyInjection\Extension\ExtensionInterface;
use Symfony\Component\Yaml\Yaml;

/**
 * A console command for dumping available configuration reference.
 *
 * @author Grégoire Pineau <lyrixx@lyrixx.info>
 *
 * @final
 */
#[AsCommand(name: 'debug:config', description: 'Dump the current configuration for an extension')]
class ConfigDebugCommand extends AbstractConfigCommand
{
    public function __construct(
        private ?ContainerInterface $envVarProcessors = null,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->setDefinition([
                new InputArgument('name', InputArgument::OPTIONAL, 'The bundle name or the extension alias'),
                new InputArgument('path', InputArgument::OPTIONAL, 'The configuration option path'),
                new InputOption('resolve-env', null, InputOption::VALUE_NONE, 'Display resolved environment variable values instead of placeholders'),
                new InputOption('format', null, InputOption::VALUE_REQUIRED, \sprintf('The output format ("%s")', implode('", "', $this->getAvailableFormatOptions())), class_exists(Yaml::class) ? 'txt' : 'json'),
            ])
            ->setHelp(<<<EOF
                The <info>%command.name%</info> command dumps the current configuration for an
                extension/bundle.

                Either the extension alias or bundle name can be used:

                  <info>php %command.full_name% framework</info>
                  <info>php %command.full_name% FrameworkBundle</info>

                The <info>--format</info> option specifies the format of the command output:

                  <info>php %command.full_name% framework --format=json</info>

                For dumping a specific option, add its path as second argument:

                  <info>php %command.full_name% framework serializer.enabled</info>

                EOF
            )
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $errorIo = $io->getErrorStyle();

        if (null === $name = $input->getArgument('name')) {
            $this->listBundles($errorIo);
            $this->listNonBundleExtensions($errorIo);

            $errorIo->comment('Provide the name of a bundle as the first argument of this command to dump its configuration. (e.g. <comment>debug:config FrameworkBundle</comment>)');
            $errorIo->comment('For dumping a specific option, add its path as the second argument of this command. (e.g. <comment>debug:config FrameworkBundle serializer</comment> to dump the <comment>framework.serializer</comment> configuration)');

            return 0;
        }

        $extension = $this->findExtension($name);
        $extensionAlias = $extension->getAlias();
        $container = $this->compileContainer();

        $config = $this->getConfig($extension, $container, $input->getOption('resolve-env'));

        $format = $input->getOption('format');

        if (\in_array($format, ['txt', 'yaml'], true) && !class_exists(Yaml::class)) {
            $errorIo->error('Setting the "format" option to "txt" or "yaml" requires the Symfony Yaml component. Try running "composer install symfony/yaml" or use "--format=json" instead.');

            return 1;
        }

        if (null === $path = $input->getArgument('path')) {
            if ('txt' === $input->getOption('format')) {
                $io->title(
                    \sprintf('Current configuration for %s', OutputFormatter::escape($name === $extensionAlias ? \sprintf('extension with alias "%s"', $extensionAlias) : \sprintf('"%s"', $name)))
                );

                if ($docUrl = $this->getDocUrl($extension, $container)) {
                    $io->comment(\sprintf('Documentation at %s', OutputFormatter::escape($docUrl)));
                }
            }

            $io->writeln($this->convertToFormat([$extensionAlias => $config], $format), OutputInterface::OUTPUT_RAW);

            return 0;
        }

        try {
            $config = $this->getConfigForPath($config, $path, $extensionAlias);
        } catch (LogicException $e) {
            $errorIo->error($e->getMessage());

            return 1;
        }

        if ('txt' === $format) {
            $io->title(\sprintf('Current configuration for "%s.%s"', OutputFormatter::escape($extensionAlias), OutputFormatter::escape($path)));
        }

        $io->writeln($this->convertToFormat($config, $format), OutputInterface::OUTPUT_RAW);

        return 0;
    }

    private function convertToFormat(mixed $config, string $format): string
    {
        return match ($format) {
            'txt', 'yaml' => Yaml::dump($config, 10),
            'json' => json_encode($config, \JSON_PRETTY_PRINT | \JSON_UNESCAPED_SLASHES | \JSON_UNESCAPED_UNICODE | \JSON_INVALID_UTF8_SUBSTITUTE),
            default => throw new InvalidArgumentException(\sprintf('Supported formats are "%s".', implode('", "', $this->getAvailableFormatOptions()))),
        };
    }

    private function compileContainer(): ContainerBuilder
    {
        $kernel = clone $this->getApplication()->getKernel();
        $buildContainer = \Closure::bind(function (): ContainerBuilder {
            $this->initializeBundles();

            return $this->buildContainer();
        }, $kernel, $kernel::class);
        $container = $buildContainer();
        if ($this->envVarProcessors) {
            $container->set('container.env_var_processors_locator', $this->envVarProcessors);
        }
        $container->getCompiler()->compile($container);

        return $container;
    }

    /**
     * Iterate over configuration until the last step of the given path.
     *
     * @throws LogicException If the configuration does not exist
     */
    private function getConfigForPath(array $config, string $path, string $alias): mixed
    {
        $steps = explode('.', $path);

        foreach ($steps as $step) {
            if (!\is_array($config) || !\array_key_exists($step, $config)) {
                throw new LogicException(\sprintf('Unable to find configuration for "%s.%s".', $alias, $path));
            }

            $config = $config[$step];
        }

        return $config;
    }

    private function getConfigForExtension(ExtensionInterface $extension, ContainerBuilder $container): array
    {
        $extensionAlias = $extension->getAlias();

        $extensionConfig = [];
        foreach ($container->getCompilerPassConfig()->getPasses() as $pass) {
            if ($pass instanceof ValidateEnvPlaceholdersPass) {
                $extensionConfig = $pass->getExtensionConfig();
                break;
            }
        }

        if (isset($extensionConfig[$extensionAlias])) {
            return $extensionConfig[$extensionAlias];
        }

        // Fall back to default config if the extension has one

        if (!$extension instanceof ConfigurationExtensionInterface && !$extension instanceof ConfigurationInterface) {
            throw new \LogicException(\sprintf('The extension with alias "%s" does not have configuration.', $extensionAlias));
        }

        $configs = $container->getExtensionConfig($extensionAlias);
        $configuration = $extension instanceof ConfigurationInterface ? $extension : $extension->getConfiguration($configs, $container);
        $this->validateConfiguration($extension, $configuration);

        return (new Processor())->processConfiguration($configuration, $configs);
    }

    public function complete(CompletionInput $input, CompletionSuggestions $suggestions): void
    {
        if ($input->mustSuggestArgumentValuesFor('name')) {
            $suggestions->suggestValues($this->getAvailableExtensions());
            $suggestions->suggestValues($this->getAvailableBundles());

            return;
        }

        if ($input->mustSuggestArgumentValuesFor('path') && null !== $name = $input->getArgument('name')) {
            try {
                $config = $this->getConfig($this->findExtension($name), $this->compileContainer());
                $paths = array_keys(self::buildPathsCompletion($config));
                $suggestions->suggestValues($paths);
            } catch (LogicException) {
            }
        }

        if ($input->mustSuggestOptionValuesFor('format')) {
            $suggestions->suggestValues($this->getAvailableFormatOptions());
        }
    }

    private function getAvailableExtensions(): array
    {
        $kernel = $this->getApplication()->getKernel();

        $extensions = [];
        foreach ($this->getContainerBuilder($kernel)->getExtensions() as $alias => $extension) {
            $extensions[] = $alias;
        }

        return $extensions;
    }

    private function getAvailableBundles(): array
    {
        $availableBundles = [];
        foreach ($this->getApplication()->getKernel()->getBundles() as $bundle) {
            $availableBundles[] = $bundle->getName();
        }

        return $availableBundles;
    }

    private function getConfig(ExtensionInterface $extension, ContainerBuilder $container, bool $resolveEnvs = false): mixed
    {
        return $container->resolveEnvPlaceholders(
            $container->getParameterBag()->resolveValue(
                $this->getConfigForExtension($extension, $container)
            ), $resolveEnvs ?: null
        );
    }

    private static function buildPathsCompletion(array $paths, string $prefix = ''): array
    {
        $completionPaths = [];
        foreach ($paths as $key => $values) {
            if (\is_array($values)) {
                $completionPaths += self::buildPathsCompletion($values, $prefix.$key.'.');
            } else {
                $completionPaths[$prefix.$key] = null;
            }
        }

        return $completionPaths;
    }

    /** @return string[] */
    private function getAvailableFormatOptions(): array
    {
        return ['txt', 'yaml', 'json'];
    }

    private function getDocUrl(ExtensionInterface $extension, ContainerBuilder $container): ?string
    {
        $configuration = $extension instanceof ConfigurationInterface ? $extension : $extension->getConfiguration($container->getExtensionConfig($extension->getAlias()), $container);

        return $configuration
            ->getConfigTreeBuilder()
            ->getRootNode()
            ->getNode(true)
            ->getAttribute('docUrl');
    }
}
