<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Component\HttpFoundation\Session\Storage\Handler;

use Symfony\Component\HttpFoundation\Session\SessionUtils;

/**
 * This abstract session handler provides a generic implementation
 * of the PHP 7.0 SessionUpdateTimestampHandlerInterface,
 * enabling strict and lazy session handling.
 *
 * @author Nicolas Grekas <p@tchwork.com>
 */
abstract class AbstractSessionHandler implements \SessionHandlerInterface, \SessionUpdateTimestampHandlerInterface
{
    private string $sessionName;
    private string $prefetchId;
    private string|false $prefetchData;
    private ?\Throwable $prefetchError = null;
    private ?string $newSessionId = null;
    private ?string $readSessionId = null;
    private string $igbinaryEmptyData;

    public function __serialize(): array
    {
        throw new \BadMethodCallException('Cannot serialize '.static::class);
    }

    public function __unserialize(array $data): void
    {
        throw new \BadMethodCallException('Cannot unserialize '.static::class);
    }

    public function open(string $savePath, string $sessionName): bool
    {
        $this->sessionName = $sessionName;
        if (!headers_sent() && !\ini_get('session.cache_limiter') && '0' !== \ini_get('session.cache_limiter')) {
            header(\sprintf('Cache-Control: max-age=%d, private, must-revalidate', 60 * (int) \ini_get('session.cache_expire')));
        }

        return true;
    }

    public function create_sid(): string
    {
        return session_create_id() ?: throw new \RuntimeException('Unable to create a session ID.');
    }

    abstract protected function doRead(#[\SensitiveParameter] string $sessionId): string|false;

    abstract protected function doWrite(#[\SensitiveParameter] string $sessionId, string $data): bool;

    abstract protected function doDestroy(#[\SensitiveParameter] string $sessionId): bool;

    public function validateId(#[\SensitiveParameter] string $sessionId): bool
    {
        // Reporting a failed read as an invalid ID would make PHP issue a new ID and cookie, orphaning the session.
        // Keep the ID instead and let the failure surface from read().
        try {
            $this->prefetchData = $this->read($sessionId);
        } catch (\Throwable $e) {
            $this->prefetchData = false;
            $this->prefetchError = $e;
        }
        $this->prefetchId = $sessionId;

        return '' !== $this->prefetchData;
    }

    public function read(#[\SensitiveParameter] string $sessionId): string|false
    {
        $this->readSessionId = $sessionId;

        if (isset($this->prefetchId)) {
            $prefetchId = $this->prefetchId;
            $prefetchData = $this->prefetchData;
            $prefetchError = $this->prefetchError;
            unset($this->prefetchId, $this->prefetchData);
            $this->prefetchError = null;

            if ($prefetchId === $sessionId || '' === $prefetchData) {
                if ($prefetchError) {
                    throw $prefetchError;
                }
                $this->newSessionId = '' === $prefetchData ? $sessionId : null;

                return $prefetchData;
            }
        }

        $data = $this->doRead($sessionId);
        $this->newSessionId = '' === $data ? $sessionId : null;

        return $data;
    }

    public function updateTimestamp(#[\SensitiveParameter] string $sessionId, string $data): bool
    {
        $this->igbinaryEmptyData ??= \function_exists('igbinary_serialize') ? igbinary_serialize([]) : '';
        if ('' === $data || $this->igbinaryEmptyData === $data) {
            return $this->destroy($sessionId);
        }

        return true;
    }

    public function write(#[\SensitiveParameter] string $sessionId, string $data): bool
    {
        // see https://github.com/igbinary/igbinary/issues/146
        $this->igbinaryEmptyData ??= \function_exists('igbinary_serialize') ? igbinary_serialize([]) : '';
        if ('' === $data || $this->igbinaryEmptyData === $data) {
            return $this->destroy($sessionId);
        }
        $this->newSessionId = null;

        return $this->doWrite($sessionId, $data);
    }

    public function destroy(#[\SensitiveParameter] string $sessionId): bool
    {
        // only the handler that read the session manages its cookie, e.g. not the write-only handler of MigratingSessionHandler
        if ($this->readSessionId === $sessionId && !headers_sent() && filter_var(\ini_get('session.use_cookies'), \FILTER_VALIDATE_BOOL)) {
            if (!isset($this->sessionName)) {
                throw new \LogicException(\sprintf('Session name cannot be empty, did you forget to call "parent::open()" in "%s"?.', static::class));
            }
            $cookie = SessionUtils::popSessionCookie($this->sessionName, $sessionId);

            /*
             * We send an invalidation Set-Cookie header (zero lifetime)
             * when either the session was started or a cookie with
             * the session name was sent by the client (in which case
             * we know it's invalid as a valid session cookie would've
             * started the session).
             */
            if (null === $cookie || isset($_COOKIE[$this->sessionName])) {
                $params = session_get_cookie_params();
                unset($params['lifetime']);
                setcookie($this->sessionName, '', $params);
            }
        }

        return $this->newSessionId === $sessionId || $this->doDestroy($sessionId);
    }
}
