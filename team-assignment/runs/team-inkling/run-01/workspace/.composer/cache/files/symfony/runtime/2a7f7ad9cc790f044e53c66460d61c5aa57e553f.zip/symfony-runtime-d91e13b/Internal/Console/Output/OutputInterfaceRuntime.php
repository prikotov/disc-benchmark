<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Runtime\Symfony\Component\Console\Output;

use Symfony\Component\Runtime\SymfonyRuntime;

/**
 * @internal
 */
class OutputInterfaceRuntime extends SymfonyRuntime
{
}
