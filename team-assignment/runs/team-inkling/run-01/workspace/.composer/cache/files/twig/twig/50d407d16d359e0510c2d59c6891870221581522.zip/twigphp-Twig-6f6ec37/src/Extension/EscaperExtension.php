<?php

/*
 * This file is part of Twig.
 *
 * (c) Fabien Potencier
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Twig\Extension;

use Twig\Environment;
use Twig\FileExtensionEscapingStrategy;
use Twig\Node\Expression\ConstantExpression;
use Twig\Node\Expression\Filter\EscapeFilter;
use Twig\Node\Expression\Filter\RawFilter;
use Twig\Node\Node;
use Twig\NodeVisitor\EscaperNodeVisitor;
use Twig\Runtime\EscaperRuntime;
use Twig\TokenParser\AutoEscapeTokenParser;
use Twig\TwigFilter;

final class EscaperExtension extends AbstractExtension
{
    private const MAX_RESOLVED_DEFAULT_STRATEGIES = 1000;

    private $environment;
    private $escapers = [];
    private $escaper;
    private $defaultStrategy;
    /** @var array<string, mixed> */
    private array $resolvedDefaultStrategies = [];

    /**
     * @param string|false|callable $defaultStrategy An escaping strategy
     *
     * @see setDefaultStrategy()
     */
    public function __construct($defaultStrategy = 'html')
    {
        $this->setDefaultStrategy($defaultStrategy);
    }

    public function getTokenParsers(): array
    {
        return [new AutoEscapeTokenParser()];
    }

    public function getNodeVisitors(): array
    {
        return [new EscaperNodeVisitor()];
    }

    public function getFilters(): array
    {
        return [
            new TwigFilter('escape', [EscaperRuntime::class, 'escape'], ['is_safe_callback' => [self::class, 'escapeFilterIsSafe'], 'node_class' => EscapeFilter::class]),
            new TwigFilter('e', [EscaperRuntime::class, 'escape'], ['is_safe_callback' => [self::class, 'escapeFilterIsSafe'], 'node_class' => EscapeFilter::class]),
            new TwigFilter('raw', null, ['is_safe' => ['all'], 'node_class' => RawFilter::class]),
        ];
    }

    public function getLastModified(): int
    {
        return max(
            parent::getLastModified(),
            filemtime((new \ReflectionClass(EscaperRuntime::class))->getFileName()),
        );
    }

    /**
     * @deprecated since Twig 3.10
     */
    public function setEnvironment(Environment $environment): void
    {
        $triggerDeprecation = \func_num_args() > 1 ? func_get_arg(1) : true;
        if ($triggerDeprecation) {
            trigger_deprecation('twig/twig', '3.10', 'The "%s()" method is deprecated and not needed if you are using methods from "Twig\Runtime\EscaperRuntime".', __METHOD__);
        }

        $this->environment = $environment;
        $this->escaper = null;
    }

    /**
     * @deprecated since Twig 3.10
     */
    public function setEscaperRuntime(EscaperRuntime $escaper): void
    {
        trigger_deprecation('twig/twig', '3.10', 'The "%s()" method is deprecated and not needed if you are using methods from "Twig\Runtime\EscaperRuntime".', __METHOD__);

        $this->escaper = $escaper;
    }

    /**
     * Sets the default strategy to use when not defined by the user.
     *
     * The strategy can be a valid PHP callback that takes the template
     * name as an argument and returns the strategy to use.
     *
     * @param string|false|callable(string $templateName): string $defaultStrategy An escaping strategy
     */
    public function setDefaultStrategy($defaultStrategy): void
    {
        if ('name' === $defaultStrategy) {
            $defaultStrategy = [FileExtensionEscapingStrategy::class, 'guess'];
        }

        $this->defaultStrategy = $defaultStrategy;
        $this->resolvedDefaultStrategies = [];
    }

    /**
     * Gets the default strategy to use when not defined by the user.
     *
     * @param string $name The template name
     *
     * @return string|false The default strategy to use for the template
     */
    public function getDefaultStrategy(string $name)
    {
        if (\array_key_exists($name, $this->resolvedDefaultStrategies)) {
            return $this->resolvedDefaultStrategies[$name];
        }

        if (\count($this->resolvedDefaultStrategies) >= self::MAX_RESOLVED_DEFAULT_STRATEGIES) {
            // array_shift() would renumber the keys of numeric template names
            unset($this->resolvedDefaultStrategies[array_key_first($this->resolvedDefaultStrategies)]);
        }

        // disable string callables to avoid calling a function named html or js,
        // or any other upcoming escaping strategy
        if (!\is_string($this->defaultStrategy) && false !== $this->defaultStrategy) {
            return $this->resolvedDefaultStrategies[$name] = \call_user_func($this->defaultStrategy, $name);
        }

        return $this->resolvedDefaultStrategies[$name] = $this->defaultStrategy;
    }

    /**
     * Defines a new escaper to be used via the escape filter.
     *
     * @param string                                        $strategy The strategy name that should be used as a strategy in the escape call
     * @param callable(Environment, string, string): string $callable A valid PHP callable
     *
     * @deprecated since Twig 3.10
     */
    public function setEscaper($strategy, callable $callable): void
    {
        trigger_deprecation('twig/twig', '3.10', 'The "%s()" method is deprecated, use the "Twig\Runtime\EscaperRuntime::setEscaper()" method instead (be warned that Environment is not passed anymore to the callable).', __METHOD__);

        $escaper = $this->getEscaper(__METHOD__);

        $this->escapers[$strategy] = $callable;
        $callable = function ($string, $charset) use ($callable) {
            return $callable($this->environment, $string, $charset);
        };

        $escaper->setEscaper($strategy, $callable);
    }

    /**
     * Gets all defined escapers.
     *
     * @return array<string, callable(Environment, string, string): string> An array of escapers
     *
     * @deprecated since Twig 3.10
     */
    public function getEscapers()
    {
        trigger_deprecation('twig/twig', '3.10', 'The "%s()" method is deprecated, use the "Twig\Runtime\EscaperRuntime::getEscaper()" method instead.', __METHOD__);

        return $this->escapers;
    }

    /**
     * @deprecated since Twig 3.10
     */
    public function setSafeClasses(array $safeClasses = []): void
    {
        trigger_deprecation('twig/twig', '3.10', 'The "%s()" method is deprecated, use the "Twig\Runtime\EscaperRuntime::setSafeClasses()" method instead.', __METHOD__);

        $this->getEscaper(__METHOD__)->setSafeClasses($safeClasses);
    }

    /**
     * @deprecated since Twig 3.10
     */
    public function addSafeClass(string $class, array $strategies): void
    {
        trigger_deprecation('twig/twig', '3.10', 'The "%s()" method is deprecated, use the "Twig\Runtime\EscaperRuntime::addSafeClass()" method instead.', __METHOD__);

        $this->getEscaper(__METHOD__)->addSafeClass($class, $strategies);
    }

    private function getEscaper(string $fromMethod): EscaperRuntime
    {
        if (isset($this->escaper)) {
            return $this->escaper;
        }

        if (isset($this->environment)) {
            return $this->escaper = $this->environment->getRuntime(EscaperRuntime::class);
        }

        throw new \LogicException(\sprintf('You must call "setEnvironment()" before calling "%s()".', $fromMethod));
    }

    /**
     * @internal
     *
     * @return array<string>
     */
    public static function escapeFilterIsSafe(Node $filterArgs)
    {
        foreach ($filterArgs as $arg) {
            if ($arg instanceof ConstantExpression) {
                return [$arg->getAttribute('value')];
            }

            return [];
        }

        return ['html'];
    }
}
